﻿#include <stdio.h>

// main 함수 이름을 exo로 바꾸었다. 당연히 에러 발생
int exo() {
    printf("Hello, World !!\n");
    printf("My name is David.\n");
    return 0;
}