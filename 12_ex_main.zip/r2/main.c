#include <stdio.h>
#include <stdlib.h>

#define EXIT_CODE_SUCCESS	(0)
#define EXIT_CODE_ERROR_1	(1)
#define EXIT_CODE_RESTART	(2)
#define EXIT_CODE_ERROR_100 (100)

int main(int argc, char *argv[]) {
	printf("****************************************\n");
	printf("[APP] Application program started !!\n");
	
	int exit_code= 0;
	printf("[APP] Input exit_code value : ");
	scanf("%d", &exit_code);
	
	//printf("exit_code is %d\n", exit_code);	
	printf("[APP] (%d) This program terminated.!!\n", exit_code);
	printf("****************************************\n");
	return exit_code;
}
